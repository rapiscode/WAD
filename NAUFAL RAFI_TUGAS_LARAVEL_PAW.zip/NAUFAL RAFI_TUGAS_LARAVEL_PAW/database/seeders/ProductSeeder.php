<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Product;
use Carbon\Carbon;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Product::create([
            'name' => 'Produk Dummy A',
            'price' => 100000,
            'created_at' => Carbon::now('Asia/Jakarta'),
        ]);

        Product::create([
            'name' => 'Produk Dummy B',
            'price' => 150000,
            'created_at' => Carbon::now('Asia/Jakarta'),
        ]);
    }
}
